package com.google.android.gms.common.util;

public abstract interface zzt<T>
{
  public abstract boolean zza(T paramT);
}
