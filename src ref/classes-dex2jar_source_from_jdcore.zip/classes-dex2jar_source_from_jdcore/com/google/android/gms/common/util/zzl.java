package com.google.android.gms.common.util;

public abstract interface zzl<F, T>
{
  public abstract T zza(F paramF);
}
