package com.google.android.gms.common.util;

public abstract interface zze
{
  public abstract long zza();
  
  public abstract long zzb();
  
  public abstract long zzc();
}
