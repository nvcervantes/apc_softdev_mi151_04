package com.google.android.gms.common.data;

import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.Hide;

@Hide
public final class zza
  implements Parcelable.Creator<BitmapTeleporter>
{
  public zza() {}
}
