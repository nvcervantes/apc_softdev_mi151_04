package com.google.android.gms.common.data;

import android.content.ContentValues;
import java.util.HashMap;

final class zze
  extends DataHolder.zza
{
  zze(String[] paramArrayOfString, String paramString)
  {
    super(paramArrayOfString, null, null);
  }
  
  public final DataHolder.zza zza(ContentValues paramContentValues)
  {
    throw new UnsupportedOperationException("Cannot add data to empty builder");
  }
  
  public final DataHolder.zza zza(HashMap<String, Object> paramHashMap)
  {
    throw new UnsupportedOperationException("Cannot add data to empty builder");
  }
}
