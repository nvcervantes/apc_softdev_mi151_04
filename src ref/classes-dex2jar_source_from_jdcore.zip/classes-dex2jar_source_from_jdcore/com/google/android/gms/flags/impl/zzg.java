package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class zzg
  implements Callable<Long>
{
  zzg(SharedPreferences paramSharedPreferences, String paramString, Long paramLong) {}
}
