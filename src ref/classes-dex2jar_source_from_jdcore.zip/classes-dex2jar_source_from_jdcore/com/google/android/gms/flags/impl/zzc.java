package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class zzc
  implements Callable<Boolean>
{
  zzc(SharedPreferences paramSharedPreferences, String paramString, Boolean paramBoolean) {}
}
