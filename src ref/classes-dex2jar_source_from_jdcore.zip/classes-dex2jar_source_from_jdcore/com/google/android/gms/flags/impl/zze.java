package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class zze
  implements Callable<Integer>
{
  zze(SharedPreferences paramSharedPreferences, String paramString, Integer paramInteger) {}
}
