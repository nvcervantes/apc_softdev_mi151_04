package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class zzi
  implements Callable<String>
{
  zzi(SharedPreferences paramSharedPreferences, String paramString1, String paramString2) {}
}
