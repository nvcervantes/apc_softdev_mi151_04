package com.google.android.gms.flags.impl;

import com.google.android.gms.common.internal.Hide;

@Hide
public class zza<T> {}
