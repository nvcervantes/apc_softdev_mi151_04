package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.concurrent.Callable;

final class zzk
  implements Callable<SharedPreferences>
{
  zzk(Context paramContext) {}
}
