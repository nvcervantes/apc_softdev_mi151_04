package com.google.android.gms.clearcut;

import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public abstract interface zzb
{
  public abstract PendingResult<Status> zza(zze paramZze);
}
