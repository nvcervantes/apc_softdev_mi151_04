package com.google.android.gms.clearcut;

import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.internal.zzbfn;

final class zza
  extends Api.zza<zzbfn, Api.ApiOptions.NoOptions>
{
  zza() {}
}
