package com.google.android.gms.internal;

public abstract interface zzat
{
  public abstract String zza(String paramString);
}
