package com.google.android.gms.internal;

import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.Hide;

@Hide
public final class zzcyn
  implements Parcelable.Creator<zzcym>
{
  public zzcyn() {}
}
