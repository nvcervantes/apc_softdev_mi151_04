package com.google.android.gms.internal;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface zzfjc
  extends zzfje
{
  public abstract int zza();
  
  public abstract void zza(zzfhg paramZzfhg)
    throws IOException;
  
  public abstract void zza(OutputStream paramOutputStream)
    throws IOException;
  
  public abstract zzfgs zzp();
  
  public abstract byte[] zzq();
  
  public abstract zzfjl<? extends zzfjc> zzr();
  
  public abstract zzfjd zzv();
}
