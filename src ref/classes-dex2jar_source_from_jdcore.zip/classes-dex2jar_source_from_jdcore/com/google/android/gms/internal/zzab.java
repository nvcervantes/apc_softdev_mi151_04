package com.google.android.gms.internal;

public abstract interface zzab
{
  public abstract int zza();
  
  public abstract void zza(zzae paramZzae)
    throws zzae;
  
  public abstract int zzb();
}
