package com.google.android.gms.internal;

final class zzbfz
  extends zzbfx<Long>
{
  zzbfz(String paramString, Long paramLong)
  {
    super(paramString, paramLong);
  }
}
