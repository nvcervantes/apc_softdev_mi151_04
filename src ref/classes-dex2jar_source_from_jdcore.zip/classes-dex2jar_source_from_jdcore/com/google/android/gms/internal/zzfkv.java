package com.google.android.gms.internal;

final class zzfkv
  extends IllegalArgumentException
{
  zzfkv(int paramInt1, int paramInt2)
  {
    super(localStringBuilder.toString());
  }
}
