package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zza;

final class zzcyh
  extends Api.zza<zzcyt, zzcyk>
{
  zzcyh() {}
}
