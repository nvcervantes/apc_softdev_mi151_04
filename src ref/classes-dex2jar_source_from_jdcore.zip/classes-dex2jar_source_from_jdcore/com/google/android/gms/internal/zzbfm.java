package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;

final class zzbfm
  extends zzbfk
{
  zzbfm(zzbfl paramZzbfl)
  {
    super(null);
  }
  
  public final void zza(Status paramStatus)
  {
    zza.zza(paramStatus);
  }
}
