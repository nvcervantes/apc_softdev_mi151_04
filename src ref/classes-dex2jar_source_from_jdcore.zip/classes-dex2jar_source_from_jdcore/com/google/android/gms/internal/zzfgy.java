package com.google.android.gms.internal;

abstract class zzfgy
  extends zzfgs
{
  zzfgy() {}
  
  abstract boolean zza(zzfgs paramZzfgs, int paramInt1, int paramInt2);
  
  protected final int zze()
  {
    return 0;
  }
  
  protected final boolean zzf()
  {
    return true;
  }
}
