package com.google.android.gms.internal;

final class zzcza
  implements Runnable
{
  zzcza(zzcyz paramZzcyz) {}
  
  public final void run()
  {
    zzcyz.zza(zza, 0);
  }
}
