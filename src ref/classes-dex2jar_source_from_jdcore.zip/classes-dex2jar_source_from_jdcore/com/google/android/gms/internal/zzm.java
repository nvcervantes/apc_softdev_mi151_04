package com.google.android.gms.internal;

public abstract interface zzm
{
  public abstract zzp zza(zzr<?> paramZzr)
    throws zzae;
}
