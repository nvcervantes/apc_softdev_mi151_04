package com.google.android.gms.internal;

public final class zza
  extends zzae
{
  public zza() {}
  
  public zza(zzp paramZzp)
  {
    super(paramZzp);
  }
}
