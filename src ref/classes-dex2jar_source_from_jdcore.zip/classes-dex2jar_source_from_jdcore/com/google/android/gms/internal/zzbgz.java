package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;

abstract class zzbgz
  extends zzbgy<Status>
{
  public zzbgz(GoogleApiClient paramGoogleApiClient)
  {
    super(paramGoogleApiClient);
  }
}
