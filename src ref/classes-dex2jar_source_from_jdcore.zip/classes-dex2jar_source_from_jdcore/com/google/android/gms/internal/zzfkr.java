package com.google.android.gms.internal;

import java.security.PrivilegedExceptionAction;
import sun.misc.Unsafe;

final class zzfkr
  implements PrivilegedExceptionAction<Unsafe>
{
  zzfkr() {}
}
