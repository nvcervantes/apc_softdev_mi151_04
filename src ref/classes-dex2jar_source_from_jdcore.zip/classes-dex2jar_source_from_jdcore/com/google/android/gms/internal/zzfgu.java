package com.google.android.gms.internal;

import java.util.Arrays;

final class zzfgu
  implements zzfgw
{
  private zzfgu() {}
  
  public final byte[] zza(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return Arrays.copyOfRange(paramArrayOfByte, paramInt1, paramInt2 + paramInt1);
  }
}
