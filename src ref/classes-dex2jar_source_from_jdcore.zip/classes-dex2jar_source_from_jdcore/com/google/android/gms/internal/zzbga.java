package com.google.android.gms.internal;

final class zzbga
  extends zzbfx<Integer>
{
  zzbga(String paramString, Integer paramInteger)
  {
    super(paramString, paramInteger);
  }
}
