package com.google.android.gms.internal;

abstract interface zzfjb
{
  public abstract boolean zza(Class<?> paramClass);
  
  public abstract zzfja zzb(Class<?> paramClass);
}
