package com.google.android.gms.internal;

final class zzbgc
  extends zzbfx<String>
{
  zzbgc(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }
}
