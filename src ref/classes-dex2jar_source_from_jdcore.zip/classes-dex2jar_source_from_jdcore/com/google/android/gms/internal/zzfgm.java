package com.google.android.gms.internal;

public abstract class zzfgm<MessageType extends zzfjc>
  implements zzfjl<MessageType>
{
  private static final zzfhm zza = ;
  
  public zzfgm() {}
}
