package com.google.android.gms.internal;

import android.support.v4.content.WakefulBroadcastReceiver;
import com.google.android.gms.common.internal.Hide;

@Hide
public abstract class zzcyy
  extends WakefulBroadcastReceiver
{
  private static String zza = "GCoreWakefulBroadcastReceiver";
}
