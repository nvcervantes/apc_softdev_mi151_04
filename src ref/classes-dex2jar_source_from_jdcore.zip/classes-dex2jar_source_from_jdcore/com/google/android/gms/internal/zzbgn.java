package com.google.android.gms.internal;

import android.os.Parcel;

public final class zzbgn
  extends RuntimeException
{
  public zzbgn(String paramString, Parcel paramParcel)
  {
    super(paramParcel.toString());
  }
}
