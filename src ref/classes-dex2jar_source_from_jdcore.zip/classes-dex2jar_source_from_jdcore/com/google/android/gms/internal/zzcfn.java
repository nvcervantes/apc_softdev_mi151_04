package com.google.android.gms.internal;

import android.app.PendingIntent;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.ActivityTransitionRequest;

final class zzcfn
  extends zzcfp
{
  zzcfn(zzcfk paramZzcfk, GoogleApiClient paramGoogleApiClient, ActivityTransitionRequest paramActivityTransitionRequest, PendingIntent paramPendingIntent)
  {
    super(paramGoogleApiClient);
  }
}
