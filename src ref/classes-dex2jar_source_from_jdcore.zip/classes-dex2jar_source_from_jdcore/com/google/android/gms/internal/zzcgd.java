package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;

final class zzcgd
  extends zzcgj
{
  zzcgd(zzcfy paramZzcfy, GoogleApiClient paramGoogleApiClient)
  {
    super(paramGoogleApiClient);
  }
}
