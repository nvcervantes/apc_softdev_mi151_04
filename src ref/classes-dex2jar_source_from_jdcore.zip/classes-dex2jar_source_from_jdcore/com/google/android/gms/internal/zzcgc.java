package com.google.android.gms.internal;

import android.location.Location;
import com.google.android.gms.common.api.GoogleApiClient;

final class zzcgc
  extends zzcgj
{
  zzcgc(zzcfy paramZzcfy, GoogleApiClient paramGoogleApiClient, Location paramLocation)
  {
    super(paramGoogleApiClient);
  }
}
