package com.google.android.gms.internal;

public abstract interface zzfia
{
  public abstract int zza();
}
