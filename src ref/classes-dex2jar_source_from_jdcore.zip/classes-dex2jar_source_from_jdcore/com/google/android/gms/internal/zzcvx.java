package com.google.android.gms.internal;

import android.os.IBinder;

public final class zzcvx
  extends zzev
  implements zzcvw
{
  zzcvx(IBinder paramIBinder)
  {
    super(paramIBinder, "com.google.android.gms.phenotype.internal.IPhenotypeService");
  }
}
