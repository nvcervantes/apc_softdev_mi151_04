package com.google.android.gms.internal;

abstract interface zzfix {}
