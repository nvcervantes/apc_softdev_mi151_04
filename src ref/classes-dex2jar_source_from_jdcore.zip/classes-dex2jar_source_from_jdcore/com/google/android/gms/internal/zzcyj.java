package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.internal.zzan;

public abstract interface zzcyj
  extends Api.zze
{
  public abstract void zza(zzan paramZzan, boolean paramBoolean);
  
  public abstract void zza(zzcyp paramZzcyp);
  
  public abstract void zzh();
  
  public abstract void zzi();
}
