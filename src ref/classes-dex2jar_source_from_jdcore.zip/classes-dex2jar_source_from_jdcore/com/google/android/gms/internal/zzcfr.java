package com.google.android.gms.internal;

final class zzcfr
  implements zzchr<zzcgw>
{
  zzcfr(zzcfq paramZzcfq) {}
  
  public final void zza()
  {
    zzcfq.zza(zza);
  }
}
