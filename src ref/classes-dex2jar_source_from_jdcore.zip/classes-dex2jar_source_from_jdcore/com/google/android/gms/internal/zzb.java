package com.google.android.gms.internal;

public abstract interface zzb
{
  public abstract zzc zza(String paramString);
  
  public abstract void zza();
  
  public abstract void zza(String paramString, zzc paramZzc);
}
