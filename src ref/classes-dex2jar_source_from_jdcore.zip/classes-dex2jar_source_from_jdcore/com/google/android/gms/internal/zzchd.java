package com.google.android.gms.internal;

import com.google.android.gms.common.api.internal.zzcl;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;

final class zzchd
  implements zzcl<LocationCallback>
{
  zzchd(zzchb paramZzchb, LocationAvailability paramLocationAvailability) {}
  
  public final void zza() {}
}
