package com.google.android.gms.internal;

import com.google.android.gms.clearcut.zzc;
import com.google.android.gms.clearcut.zze;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

class zzbfk
  extends zzbfq
{
  private zzbfk() {}
  
  public void zza(Status paramStatus)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zza(Status paramStatus, long paramLong)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zza(Status paramStatus, zzc paramZzc)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zza(Status paramStatus, zze[] paramArrayOfZze)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zza(DataHolder paramDataHolder)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zzb(Status paramStatus)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zzb(Status paramStatus, long paramLong)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zzb(Status paramStatus, zzc paramZzc)
  {
    throw new UnsupportedOperationException();
  }
  
  public final void zzc(Status paramStatus)
  {
    throw new UnsupportedOperationException();
  }
}
