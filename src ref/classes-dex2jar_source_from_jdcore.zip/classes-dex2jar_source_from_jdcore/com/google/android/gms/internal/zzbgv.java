package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public final class zzbgv
  implements zzbgu
{
  public zzbgv() {}
  
  public final PendingResult<Status> zza(GoogleApiClient paramGoogleApiClient)
  {
    return paramGoogleApiClient.zzb(new zzbgw(this, paramGoogleApiClient));
  }
}
