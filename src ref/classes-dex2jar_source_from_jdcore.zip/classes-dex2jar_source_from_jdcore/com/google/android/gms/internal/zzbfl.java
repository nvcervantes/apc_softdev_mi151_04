package com.google.android.gms.internal;

import com.google.android.gms.clearcut.ClearcutLogger;
import com.google.android.gms.clearcut.zze;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.zzm;

final class zzbfl
  extends zzm<Status, zzbfn>
{
  private final zze zza;
  
  zzbfl(zze paramZze, GoogleApiClient paramGoogleApiClient)
  {
    super(ClearcutLogger.zza, paramGoogleApiClient);
    zza = paramZze;
  }
}
