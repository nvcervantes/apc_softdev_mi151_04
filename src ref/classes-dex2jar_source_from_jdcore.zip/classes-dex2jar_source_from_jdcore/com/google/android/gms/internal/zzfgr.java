package com.google.android.gms.internal;

import java.io.IOException;

public abstract class zzfgr
{
  public zzfgr() {}
  
  public abstract void zza(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;
}
