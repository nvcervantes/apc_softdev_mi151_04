package com.google.android.gms.internal;

import android.location.Location;
import com.google.android.gms.common.api.internal.zzcl;
import com.google.android.gms.location.LocationListener;

final class zzchg
  implements zzcl<LocationListener>
{
  zzchg(zzchf paramZzchf, Location paramLocation) {}
  
  public final void zza() {}
}
