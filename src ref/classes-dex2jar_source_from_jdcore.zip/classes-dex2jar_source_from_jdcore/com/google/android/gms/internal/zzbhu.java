package com.google.android.gms.internal;

import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.Hide;

@Hide
public final class zzbhu
  implements Parcelable.Creator<zzbhx>
{
  public zzbhu() {}
}
