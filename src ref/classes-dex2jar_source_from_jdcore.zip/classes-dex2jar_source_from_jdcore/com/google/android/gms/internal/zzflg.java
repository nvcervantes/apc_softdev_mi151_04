package com.google.android.gms.internal;

import java.io.IOException;

 enum zzflg
{
  zzflg()
  {
    super(str, 1, null);
  }
  
  final Object zza(zzfhb paramZzfhb)
    throws IOException
  {
    return paramZzfhb.zzk();
  }
}
