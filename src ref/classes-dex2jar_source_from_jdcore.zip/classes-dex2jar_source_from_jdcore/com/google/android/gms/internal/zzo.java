package com.google.android.gms.internal;

public class zzo
  extends zzae
{
  public zzo() {}
  
  public zzo(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}
