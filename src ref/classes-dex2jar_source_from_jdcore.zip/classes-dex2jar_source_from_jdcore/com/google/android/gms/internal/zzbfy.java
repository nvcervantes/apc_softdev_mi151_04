package com.google.android.gms.internal;

final class zzbfy
  extends zzbfx<Boolean>
{
  zzbfy(String paramString, Boolean paramBoolean)
  {
    super(paramString, paramBoolean);
  }
}
