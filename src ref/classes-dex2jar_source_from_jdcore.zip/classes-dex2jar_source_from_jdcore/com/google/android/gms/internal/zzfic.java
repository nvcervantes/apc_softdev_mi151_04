package com.google.android.gms.internal;

public abstract interface zzfic
  extends zzfid<Integer>
{
  public abstract zzfic zza(int paramInt);
  
  public abstract int zzb(int paramInt);
  
  public abstract void zzc(int paramInt);
}
