package com.google.android.gms.internal;

public enum zzfky
{
  private final zzfld zzs;
  private final int zzt;
  
  private zzfky(zzfld paramZzfld, int paramInt)
  {
    zzs = paramZzfld;
    zzt = paramInt;
  }
  
  public final zzfld zza()
  {
    return zzs;
  }
  
  public final int zzb()
  {
    return zzt;
  }
}
