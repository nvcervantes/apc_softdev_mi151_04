package com.google.android.gms.internal;

import java.util.List;
import java.util.RandomAccess;

public abstract interface zzfid<E>
  extends List<E>, RandomAccess
{
  public abstract boolean zza();
  
  public abstract void zzb();
  
  public abstract zzfid<E> zzd(int paramInt);
}
