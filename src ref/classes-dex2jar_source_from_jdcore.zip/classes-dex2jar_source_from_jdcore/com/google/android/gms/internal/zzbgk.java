package com.google.android.gms.internal;

import android.graphics.drawable.Drawable;
import android.support.v4.util.LruCache;

public final class zzbgk
  extends LruCache<Object, Drawable>
{
  public zzbgk()
  {
    super(10);
  }
}
