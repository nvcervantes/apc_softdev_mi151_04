package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.clearcut.zze;

public abstract interface zzbfr
  extends IInterface
{
  public abstract void zza(zzbfp paramZzbfp, zze paramZze)
    throws RemoteException;
}
