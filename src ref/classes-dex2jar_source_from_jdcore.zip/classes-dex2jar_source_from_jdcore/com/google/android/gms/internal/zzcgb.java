package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;

final class zzcgb
  extends zzcgj
{
  zzcgb(zzcfy paramZzcfy, GoogleApiClient paramGoogleApiClient, boolean paramBoolean)
  {
    super(paramGoogleApiClient);
  }
}
