package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.common.api.Api.zzf;

public final class zzbgs
{
  public static final Api.zzf<zzbha> zza = new Api.zzf();
  public static final Api<Api.ApiOptions.NoOptions> zzb = new Api("Common.API", zzd, zza);
  public static final zzbgu zzc = new zzbgv();
  private static final Api.zza<zzbha, Api.ApiOptions.NoOptions> zzd = new zzbgt();
}
