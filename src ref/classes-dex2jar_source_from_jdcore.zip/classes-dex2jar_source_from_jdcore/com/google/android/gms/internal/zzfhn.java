package com.google.android.gms.internal;

abstract class zzfhn<T extends zzfhs<T>>
{
  zzfhn() {}
  
  abstract zzfhq<T> zza(Object paramObject);
  
  abstract boolean zza(Class<?> paramClass);
}
