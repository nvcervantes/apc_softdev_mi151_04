package com.google.android.gms.internal;

import java.util.Collections;

final class zzfio
  extends zzfim
{
  private static final Class<?> zza = Collections.unmodifiableList(Collections.emptyList()).getClass();
  
  private zzfio()
  {
    super(null);
  }
}
