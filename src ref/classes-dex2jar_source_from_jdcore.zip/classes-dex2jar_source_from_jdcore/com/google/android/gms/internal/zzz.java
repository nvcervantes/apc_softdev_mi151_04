package com.google.android.gms.internal;

public abstract interface zzz<T>
{
  public abstract void zza(T paramT);
}
