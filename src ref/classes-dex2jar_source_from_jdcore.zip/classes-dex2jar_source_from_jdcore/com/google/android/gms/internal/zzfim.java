package com.google.android.gms.internal;

class zzfim
{
  private static final zzfim zza = new zzfio(null);
  private static final zzfim zzb = new zzfip(null);
  
  private zzfim() {}
  
  static zzfim zza()
  {
    return zza;
  }
  
  static zzfim zzb()
  {
    return zzb;
  }
}
