package com.google.android.gms.internal;

final class zzs
  implements Runnable
{
  zzs(zzr paramZzr, String paramString, long paramLong) {}
  
  public final void run()
  {
    zzr.zza(zzc).zza(zza, zzb);
    zzr.zza(zzc).zza(toString());
  }
}
