package com.google.android.gms.internal;

import android.os.IInterface;

public abstract interface zzcvw
  extends IInterface
{}
