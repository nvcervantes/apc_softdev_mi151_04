package com.google.android.gms.internal;

public final class zzad
  extends zzae
{
  public zzad() {}
}
