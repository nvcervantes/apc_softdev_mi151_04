package com.google.android.gms.internal;

abstract interface zzfkj
{
  public abstract byte zza(int paramInt);
  
  public abstract int zza();
}
