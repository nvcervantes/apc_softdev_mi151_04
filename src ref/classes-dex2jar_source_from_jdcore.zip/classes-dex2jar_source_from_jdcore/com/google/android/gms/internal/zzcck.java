package com.google.android.gms.internal;

import com.google.android.gms.common.internal.Hide;
import java.util.ArrayList;
import java.util.Collection;

@Hide
public final class zzcck
{
  private final Collection<zzcce> zza = new ArrayList();
  private final Collection<zzccj> zzb = new ArrayList();
  private final Collection<zzccj> zzc = new ArrayList();
  
  public zzcck() {}
  
  public final void zza(zzcce paramZzcce)
  {
    zza.add(paramZzcce);
  }
}
