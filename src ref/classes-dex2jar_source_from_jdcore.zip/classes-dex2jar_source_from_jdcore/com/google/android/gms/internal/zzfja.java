package com.google.android.gms.internal;

abstract interface zzfja
{
  public abstract int zza();
  
  public abstract boolean zzb();
  
  public abstract zzfjc zzc();
}
