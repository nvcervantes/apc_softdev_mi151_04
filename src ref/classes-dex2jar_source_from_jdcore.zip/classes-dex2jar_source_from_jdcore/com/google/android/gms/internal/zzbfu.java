package com.google.android.gms.internal;

final class zzbfu
{
  public final String zza;
  public final long zzb;
  public final long zzc;
  
  public zzbfu(String paramString, long paramLong1, long paramLong2)
  {
    zza = paramString;
    zzb = paramLong1;
    zzc = paramLong2;
  }
}
