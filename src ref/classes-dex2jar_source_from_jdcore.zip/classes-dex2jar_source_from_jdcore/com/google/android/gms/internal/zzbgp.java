package com.google.android.gms.internal;

import android.os.Parcelable;

public abstract interface zzbgp
  extends Parcelable
{
  public static final String NULL = "SAFE_PARCELABLE_NULL_STRING";
}
