package com.google.android.gms.internal;

import java.util.Iterator;

final class zzfka
{
  private static final Iterator<Object> zza = new zzfkb();
  private static final Iterable<Object> zzb = new zzfkc();
  
  static <T> Iterable<T> zza()
  {
    return zzb;
  }
}
