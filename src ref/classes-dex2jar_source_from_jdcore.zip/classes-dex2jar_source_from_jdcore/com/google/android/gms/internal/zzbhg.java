package com.google.android.gms.internal;

import com.google.android.gms.common.internal.Hide;

@Hide
public final class zzbhg
{
  private static zzbhi zza;
  
  @Hide
  public static zzbhi zza()
  {
    try
    {
      if (zza == null) {
        zza = new zzbhh();
      }
      zzbhi localZzbhi = zza;
      return localZzbhi;
    }
    finally {}
  }
}
