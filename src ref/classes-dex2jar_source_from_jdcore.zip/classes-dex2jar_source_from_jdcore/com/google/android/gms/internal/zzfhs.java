package com.google.android.gms.internal;

public abstract interface zzfhs<T extends zzfhs<T>>
  extends Comparable<T>
{
  public abstract int zza();
  
  public abstract zzfky zzb();
  
  public abstract zzfld zzc();
  
  public abstract boolean zzd();
  
  public abstract boolean zze();
}
