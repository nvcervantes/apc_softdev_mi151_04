package com.google.android.gms.internal;

import java.lang.reflect.Constructor;

final class zzfiz
{
  private static final zzfix zza = ;
  private static final zzfix zzb = new zzfiy();
  
  static zzfix zza()
  {
    return zza;
  }
  
  static zzfix zzb()
  {
    return zzb;
  }
  
  private static zzfix zzc()
  {
    try
    {
      zzfix localZzfix = (zzfix)Class.forName("com.google.protobuf.MapFieldSchemaFull").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
      return localZzfix;
    }
    catch (Exception localException)
    {
      for (;;) {}
    }
    return null;
  }
}
