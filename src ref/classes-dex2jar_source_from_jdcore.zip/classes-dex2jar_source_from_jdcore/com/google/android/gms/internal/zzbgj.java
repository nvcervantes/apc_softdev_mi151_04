package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.net.Uri;
import android.widget.ImageView;
import com.google.android.gms.common.internal.Hide;

@Hide
public final class zzbgj
  extends ImageView
{
  public static int zza()
  {
    throw new NoSuchMethodError();
  }
  
  public static void zza(int paramInt)
  {
    throw new NoSuchMethodError();
  }
  
  public static void zza(Uri paramUri)
  {
    throw new NoSuchMethodError();
  }
  
  protected final void onDraw(Canvas paramCanvas)
  {
    throw new NoSuchMethodError();
  }
  
  protected final void onMeasure(int paramInt1, int paramInt2)
  {
    throw new NoSuchMethodError();
  }
}
