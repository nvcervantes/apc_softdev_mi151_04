package com.google.android.gms.internal;

final class zzfha
  implements zzfgw
{
  private zzfha() {}
  
  public final byte[] zza(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[paramInt2];
    System.arraycopy(paramArrayOfByte, paramInt1, arrayOfByte, 0, paramInt2);
    return arrayOfByte;
  }
}
