package com.google.android.gms.internal;

public abstract interface zzaa
{
  public abstract void zza(zzr<?> paramZzr, zzae paramZzae);
  
  public abstract void zza(zzr<?> paramZzr, zzx<?> paramZzx);
  
  public abstract void zza(zzr<?> paramZzr, zzx<?> paramZzx, Runnable paramRunnable);
}
