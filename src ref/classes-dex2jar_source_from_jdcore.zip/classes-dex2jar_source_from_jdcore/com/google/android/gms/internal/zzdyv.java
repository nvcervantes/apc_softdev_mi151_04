package com.google.android.gms.internal;

import java.io.PrintStream;
import java.io.PrintWriter;

final class zzdyv
  extends zzdyr
{
  zzdyv() {}
  
  public final void zza(Throwable paramThrowable, PrintStream paramPrintStream)
  {
    paramThrowable.printStackTrace(paramPrintStream);
  }
  
  public final void zza(Throwable paramThrowable, PrintWriter paramPrintWriter)
  {
    paramThrowable.printStackTrace(paramPrintWriter);
  }
}
