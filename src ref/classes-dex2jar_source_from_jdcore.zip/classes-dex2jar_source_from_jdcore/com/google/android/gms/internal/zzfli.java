package com.google.android.gms.internal;

abstract interface zzfli
{
  public abstract int zza();
  
  public abstract void zza(int paramInt, Object paramObject);
}
