package com.google.android.gms.internal;

abstract interface zzfgw
{
  public abstract byte[] zza(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
}
