package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;

public final class zzcyk
  implements Api.ApiOptions.Optional
{
  public static final zzcyk zza = new zzcyk(false, false, null, false, null, false, null, null);
  private final boolean zzb = false;
  private final boolean zzc = false;
  private final String zzd = null;
  private final boolean zze = false;
  private final String zzf = null;
  private final boolean zzg = false;
  private final Long zzh = null;
  private final Long zzi = null;
  
  static
  {
    new zzcyl();
  }
  
  private zzcyk(boolean paramBoolean1, boolean paramBoolean2, String paramString1, boolean paramBoolean3, String paramString2, boolean paramBoolean4, Long paramLong1, Long paramLong2) {}
  
  public final boolean zza()
  {
    return zzb;
  }
  
  public final boolean zzb()
  {
    return zzc;
  }
  
  public final String zzc()
  {
    return zzd;
  }
  
  public final boolean zzd()
  {
    return zze;
  }
  
  @Nullable
  public final String zze()
  {
    return zzf;
  }
  
  public final boolean zzf()
  {
    return zzg;
  }
  
  @Nullable
  public final Long zzg()
  {
    return zzh;
  }
  
  @Nullable
  public final Long zzh()
  {
    return zzi;
  }
}
