package com.google.android.gms.internal;

final class zzfho
  extends zzfhn<Object>
{
  zzfho() {}
  
  final zzfhq<Object> zza(Object paramObject)
  {
    return zzd;
  }
  
  final boolean zza(Class<?> paramClass)
  {
    return zzfhu.zzd.class.isAssignableFrom(paramClass);
  }
}
