package com.google.android.gms.internal;

public enum zzfld
{
  private final Object zzj;
  
  private zzfld(Object paramObject)
  {
    zzj = paramObject;
  }
}
