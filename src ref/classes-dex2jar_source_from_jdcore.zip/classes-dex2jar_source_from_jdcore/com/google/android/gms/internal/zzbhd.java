package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public abstract interface zzbhd
  extends IInterface
{
  public abstract void zza(zzbhb paramZzbhb)
    throws RemoteException;
}
