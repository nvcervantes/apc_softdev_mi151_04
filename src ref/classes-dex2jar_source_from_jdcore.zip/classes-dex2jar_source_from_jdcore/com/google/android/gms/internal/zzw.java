package com.google.android.gms.internal;

public abstract interface zzw<T>
{
  public abstract void zza(zzr<T> paramZzr);
}
