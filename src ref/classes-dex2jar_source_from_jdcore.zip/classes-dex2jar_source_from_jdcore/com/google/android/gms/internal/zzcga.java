package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationCallback;

final class zzcga
  extends zzcgj
{
  zzcga(zzcfy paramZzcfy, GoogleApiClient paramGoogleApiClient, LocationCallback paramLocationCallback)
  {
    super(paramGoogleApiClient);
  }
}
