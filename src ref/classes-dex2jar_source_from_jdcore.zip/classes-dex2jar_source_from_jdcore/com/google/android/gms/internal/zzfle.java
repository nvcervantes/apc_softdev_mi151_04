package com.google.android.gms.internal;

import java.io.IOException;

 enum zzfle
{
  private zzfle() {}
  
  abstract Object zza(zzfhb paramZzfhb)
    throws IOException;
}
