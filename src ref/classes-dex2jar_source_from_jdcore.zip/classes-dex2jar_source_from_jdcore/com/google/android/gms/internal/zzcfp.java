package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.ActivityRecognition.zza;

abstract class zzcfp
  extends ActivityRecognition.zza<Status>
{
  public zzcfp(GoogleApiClient paramGoogleApiClient)
  {
    super(paramGoogleApiClient);
  }
}
