package com.google.android.gms.internal;

final class zzfkg
  implements zzfja
{
  public final int zza()
  {
    throw new NoSuchMethodError();
  }
  
  public final boolean zzb()
  {
    throw new NoSuchMethodError();
  }
  
  public final zzfjc zzc()
  {
    throw new NoSuchMethodError();
  }
}
