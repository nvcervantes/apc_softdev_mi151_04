package com.google.android.gms.internal;

import java.io.IOException;

 enum zzflf
{
  zzflf()
  {
    super(str, 0, null);
  }
  
  final Object zza(zzfhb paramZzfhb)
    throws IOException
  {
    return paramZzfhb.zzj();
  }
}
