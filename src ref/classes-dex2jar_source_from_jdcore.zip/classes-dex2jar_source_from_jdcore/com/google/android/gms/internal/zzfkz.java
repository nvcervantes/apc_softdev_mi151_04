package com.google.android.gms.internal;

 enum zzfkz
{
  zzfkz(zzfld paramZzfld, int paramInt)
  {
    super(???, 8, paramZzfld, 2, null);
  }
}
