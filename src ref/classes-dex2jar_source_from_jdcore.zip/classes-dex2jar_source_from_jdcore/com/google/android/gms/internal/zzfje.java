package com.google.android.gms.internal;

public abstract interface zzfje
{
  public abstract boolean zzs();
  
  public abstract zzfjc zzw();
}
