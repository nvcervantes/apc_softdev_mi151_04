package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.zzal;

final class zzcgp
  extends zzcgq
{
  zzcgp(zzcgn paramZzcgn, GoogleApiClient paramGoogleApiClient, zzal paramZzal)
  {
    super(paramGoogleApiClient);
  }
}
