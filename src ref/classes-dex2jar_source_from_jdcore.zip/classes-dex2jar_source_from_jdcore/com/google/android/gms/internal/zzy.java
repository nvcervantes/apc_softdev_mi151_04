package com.google.android.gms.internal;

public abstract interface zzy
{
  public abstract void zza(zzae paramZzae);
}
