package com.google.android.gms.internal;

public abstract interface zzbhr<I, O>
{
  public abstract I zza(O paramO);
}
