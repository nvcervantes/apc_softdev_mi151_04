package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public abstract interface zzbhb
  extends IInterface
{
  public abstract void zza(int paramInt)
    throws RemoteException;
}
