package com.google.android.gms.internal;

final class zzbgb
  extends zzbfx<Float>
{
  zzbgb(String paramString, Float paramFloat)
  {
    super(paramString, paramFloat);
  }
}
