package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.internal.Hide;

@Hide
public abstract interface zzcgr
  extends IInterface
{
  public abstract void zza(zzcgl paramZzcgl)
    throws RemoteException;
}
