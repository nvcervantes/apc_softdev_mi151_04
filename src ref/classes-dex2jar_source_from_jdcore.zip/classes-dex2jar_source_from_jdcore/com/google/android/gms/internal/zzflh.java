package com.google.android.gms.internal;

import java.io.IOException;

 enum zzflh
{
  zzflh()
  {
    super(str, 2, null);
  }
  
  final Object zza(zzfhb paramZzfhb)
    throws IOException
  {
    return paramZzfhb.zzl();
  }
}
