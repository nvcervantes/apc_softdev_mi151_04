package com.google.android.gms.internal;

abstract class zzfkt
{
  zzfkt() {}
  
  abstract int zza(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  abstract int zza(CharSequence paramCharSequence, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
}
