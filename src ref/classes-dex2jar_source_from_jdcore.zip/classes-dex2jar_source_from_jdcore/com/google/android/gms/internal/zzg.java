package com.google.android.gms.internal;

public final class zzg
  extends zzac
{
  public zzg() {}
  
  public zzg(zzp paramZzp)
  {
    super(paramZzp);
  }
}
