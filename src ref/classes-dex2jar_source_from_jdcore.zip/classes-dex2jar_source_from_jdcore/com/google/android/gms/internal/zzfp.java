package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.internal.Hide;

@Hide
public abstract interface zzfp
  extends IInterface
{
  public abstract String zza()
    throws RemoteException;
  
  public abstract boolean zza(boolean paramBoolean)
    throws RemoteException;
  
  public abstract boolean zzb()
    throws RemoteException;
}
