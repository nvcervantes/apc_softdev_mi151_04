package com.google.android.gms.internal;

final class zzfir
  implements zzfjb
{
  zzfir() {}
  
  public final boolean zza(Class<?> paramClass)
  {
    return false;
  }
  
  public final zzfja zzb(Class<?> paramClass)
  {
    throw new IllegalStateException("This should never be called.");
  }
}
