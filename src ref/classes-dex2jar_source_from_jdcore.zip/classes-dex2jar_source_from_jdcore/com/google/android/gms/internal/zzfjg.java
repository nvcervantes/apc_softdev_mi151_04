package com.google.android.gms.internal;

import java.nio.ByteBuffer;

final class zzfjg<T>
  implements zzfjv<T>
{
  private final ByteBuffer buffer;
  
  static <T> zzfjg<T> zza(Class<T> paramClass, zzfja paramZzfja, zzfji paramZzfji, zzfim paramZzfim, zzfkn<?, ?> paramZzfkn, zzfhn<?> paramZzfhn, zzfix paramZzfix)
  {
    if ((paramZzfja instanceof zzfjp)) {
      throw new NoSuchMethodError();
    }
    paramClass = (zzfkg)paramZzfja;
    throw new NoSuchMethodError();
  }
  
  public final int zza(T paramT)
  {
    throw new NoSuchMethodError();
  }
  
  public final void zza(T paramT, zzfli paramZzfli)
  {
    throw new NoSuchMethodError();
  }
}
