package com.google.android.gms.internal;

abstract interface zzt
{
  public abstract void zza(zzr<?> paramZzr);
  
  public abstract void zza(zzr<?> paramZzr, zzx<?> paramZzx);
}
