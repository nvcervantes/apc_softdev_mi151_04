package com.google.android.gms.internal;

public class zzac
  extends zzae
{
  public zzac() {}
  
  public zzac(zzp paramZzp)
  {
    super(paramZzp);
  }
}
