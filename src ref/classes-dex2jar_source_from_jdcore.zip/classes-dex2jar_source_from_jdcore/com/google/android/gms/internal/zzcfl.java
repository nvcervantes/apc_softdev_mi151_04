package com.google.android.gms.internal;

import android.app.PendingIntent;
import com.google.android.gms.common.api.GoogleApiClient;

final class zzcfl
  extends zzcfp
{
  zzcfl(zzcfk paramZzcfk, GoogleApiClient paramGoogleApiClient, long paramLong, PendingIntent paramPendingIntent)
  {
    super(paramGoogleApiClient);
  }
}
