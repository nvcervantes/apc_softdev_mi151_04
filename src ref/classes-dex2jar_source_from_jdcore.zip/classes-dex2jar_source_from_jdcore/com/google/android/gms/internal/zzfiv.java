package com.google.android.gms.internal;

final class zzfiv<K, V>
{
  public final zzfky zza;
  public final K zzb;
  public final zzfky zzc;
  public final V zzd;
  
  public zzfiv(zzfky paramZzfky1, K paramK, zzfky paramZzfky2, V paramV)
  {
    zza = paramZzfky1;
    zzb = paramK;
    zzc = paramZzfky2;
    zzd = paramV;
  }
}
