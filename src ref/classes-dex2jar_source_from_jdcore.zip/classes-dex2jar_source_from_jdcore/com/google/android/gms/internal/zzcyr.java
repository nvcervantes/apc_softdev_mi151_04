package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.internal.zzan;

public abstract interface zzcyr
  extends IInterface
{
  public abstract void zza(int paramInt)
    throws RemoteException;
  
  public abstract void zza(zzan paramZzan, int paramInt, boolean paramBoolean)
    throws RemoteException;
  
  public abstract void zza(zzcyu paramZzcyu, zzcyp paramZzcyp)
    throws RemoteException;
}
