package com.google.android.gms.internal;

import java.util.List;

public abstract interface zzfil
  extends List
{
  public abstract List<?> zza();
  
  public abstract void zza(zzfgs paramZzfgs);
}
