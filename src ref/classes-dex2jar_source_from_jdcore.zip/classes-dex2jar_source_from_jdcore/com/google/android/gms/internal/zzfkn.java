package com.google.android.gms.internal;

abstract class zzfkn<T, B>
{
  zzfkn() {}
  
  abstract T zza(Object paramObject);
  
  abstract void zza(T paramT, zzfli paramZzfli);
  
  abstract int zzb(T paramT);
}
