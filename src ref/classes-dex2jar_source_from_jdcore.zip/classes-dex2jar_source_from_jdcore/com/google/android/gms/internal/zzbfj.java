package com.google.android.gms.internal;

import com.google.android.gms.common.api.internal.zzde;

final class zzbfj
  extends zzde<zzbfn, Void>
{}
