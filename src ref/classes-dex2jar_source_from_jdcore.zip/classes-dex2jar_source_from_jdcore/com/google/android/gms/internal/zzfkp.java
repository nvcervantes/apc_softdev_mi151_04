package com.google.android.gms.internal;

final class zzfkp
  extends zzfkn<zzfko, zzfko>
{
  zzfkp() {}
}
