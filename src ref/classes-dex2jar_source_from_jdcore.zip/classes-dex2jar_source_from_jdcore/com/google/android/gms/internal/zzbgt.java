package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.zza;

final class zzbgt
  extends Api.zza<zzbha, Api.ApiOptions.NoOptions>
{
  zzbgt() {}
}
