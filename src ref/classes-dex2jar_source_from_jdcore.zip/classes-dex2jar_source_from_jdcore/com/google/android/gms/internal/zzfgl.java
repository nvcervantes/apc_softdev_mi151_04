package com.google.android.gms.internal;

public abstract class zzfgl
  implements zzfjc, Cloneable
{
  private boolean zza = true;
  private int zzb = -1;
  
  public zzfgl() {}
}
