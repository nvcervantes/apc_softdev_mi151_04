package com.google.android.gms.internal;

public abstract interface zzfjl<MessageType>
{
  public abstract MessageType zza(zzfhb paramZzfhb, zzfhm paramZzfhm)
    throws zzfie;
  
  public abstract MessageType zzb(zzfhb paramZzfhb, zzfhm paramZzfhm)
    throws zzfie;
}
