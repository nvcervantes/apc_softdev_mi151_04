package com.google.android.gms.internal;

import java.io.IOException;

public abstract interface zzfjd
  extends zzfje, Cloneable
{
  public abstract zzfjd zza(zzfjc paramZzfjc);
  
  public abstract zzfjd zzb(zzfhb paramZzfhb, zzfhm paramZzfhm)
    throws IOException;
  
  public abstract zzfjc zze();
  
  public abstract zzfjc zzf();
}
