package com.google.android.gms.internal;

import java.io.IOException;
import java.util.Map;
import org.apache.http.HttpResponse;

@Deprecated
public abstract interface zzar
{
  public abstract HttpResponse zzb(zzr<?> paramZzr, Map<String, String> paramMap)
    throws IOException, zza;
}
