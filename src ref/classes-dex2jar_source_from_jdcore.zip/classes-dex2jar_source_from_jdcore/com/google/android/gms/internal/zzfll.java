package com.google.android.gms.internal;

import java.io.IOException;

public final class zzfll
  extends IOException
{
  zzfll(int paramInt1, int paramInt2)
  {
    super(localStringBuilder.toString());
  }
}
