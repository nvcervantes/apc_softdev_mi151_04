package com.google.android.gms.internal;

final class zzfki
  implements zzfkj
{
  zzfki(zzfgs paramZzfgs) {}
  
  public final byte zza(int paramInt)
  {
    return zza.zza(paramInt);
  }
  
  public final int zza()
  {
    return zza.zza();
  }
}
