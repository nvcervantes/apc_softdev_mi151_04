package com.google.android.gms.internal;

import java.io.PrintStream;
import java.io.PrintWriter;

abstract class zzdyr
{
  private static Throwable[] zza = new Throwable[0];
  
  zzdyr() {}
  
  public abstract void zza(Throwable paramThrowable, PrintStream paramPrintStream);
  
  public abstract void zza(Throwable paramThrowable, PrintWriter paramPrintWriter);
}
