package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;

final class zzbgw
  extends zzbgz
{
  zzbgw(zzbgv paramZzbgv, GoogleApiClient paramGoogleApiClient)
  {
    super(paramGoogleApiClient);
  }
}
