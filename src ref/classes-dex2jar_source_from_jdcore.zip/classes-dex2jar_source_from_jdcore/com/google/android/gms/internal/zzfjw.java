package com.google.android.gms.internal;

abstract interface zzfjw
{
  public abstract <T> zzfjv<T> zza(Class<T> paramClass);
}
