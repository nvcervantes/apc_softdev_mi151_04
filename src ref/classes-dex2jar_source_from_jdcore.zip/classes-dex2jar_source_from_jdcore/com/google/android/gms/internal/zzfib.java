package com.google.android.gms.internal;

public abstract interface zzfib<T extends zzfia> {}
