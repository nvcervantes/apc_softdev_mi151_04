package com.google.android.gms.internal;

abstract interface zzfjv<T>
{
  public abstract int zza(T paramT);
  
  public abstract void zza(T paramT, zzfli paramZzfli);
}
