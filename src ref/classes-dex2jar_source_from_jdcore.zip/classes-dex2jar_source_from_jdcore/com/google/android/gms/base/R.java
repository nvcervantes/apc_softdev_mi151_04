package com.google.android.gms.base;

public final class R
{
  public R() {}
}
