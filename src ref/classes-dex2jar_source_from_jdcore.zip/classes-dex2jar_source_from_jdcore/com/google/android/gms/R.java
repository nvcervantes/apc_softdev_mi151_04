package com.google.android.gms;

public final class R
{
  public R() {}
  
  public static final class attr
  {
    public static final int ambientEnabled = 2130968617;
    public static final int buttonSize = 2130968650;
    public static final int cameraBearing = 2130968655;
    public static final int cameraMaxZoomPreference = 2130968656;
    public static final int cameraMinZoomPreference = 2130968657;
    public static final int cameraTargetLat = 2130968658;
    public static final int cameraTargetLng = 2130968659;
    public static final int cameraTilt = 2130968660;
    public static final int cameraZoom = 2130968661;
    public static final int circleCrop = 2130968672;
    public static final int colorScheme = 2130968689;
    public static final int imageAspectRatio = 2130968774;
    public static final int imageAspectRatioAdjust = 2130968775;
    public static final int latLngBoundsNorthEastLatitude = 2130968787;
    public static final int latLngBoundsNorthEastLongitude = 2130968788;
    public static final int latLngBoundsSouthWestLatitude = 2130968789;
    public static final int latLngBoundsSouthWestLongitude = 2130968790;
    public static final int liteMode = 2130968859;
    public static final int mapType = 2130968862;
    public static final int scopeUris = 2130968900;
    public static final int uiCompass = 2130968996;
    public static final int uiMapToolbar = 2130968997;
    public static final int uiRotateGestures = 2130968998;
    public static final int uiScrollGestures = 2130968999;
    public static final int uiTiltGestures = 2130969000;
    public static final int uiZoomControls = 2130969001;
    public static final int uiZoomGestures = 2130969002;
    public static final int useViewLifecycle = 2130969004;
    public static final int zOrderOnTop = 2130969017;
    
    public attr() {}
  }
  
  public static final class color
  {
    public static final int common_google_signin_btn_text_dark = 2131099695;
    public static final int common_google_signin_btn_text_dark_default = 2131099696;
    public static final int common_google_signin_btn_text_dark_disabled = 2131099697;
    public static final int common_google_signin_btn_text_dark_focused = 2131099698;
    public static final int common_google_signin_btn_text_dark_pressed = 2131099699;
    public static final int common_google_signin_btn_text_light = 2131099700;
    public static final int common_google_signin_btn_text_light_default = 2131099701;
    public static final int common_google_signin_btn_text_light_disabled = 2131099702;
    public static final int common_google_signin_btn_text_light_focused = 2131099703;
    public static final int common_google_signin_btn_text_light_pressed = 2131099704;
    public static final int common_google_signin_btn_tint = 2131099705;
    public static final int place_autocomplete_prediction_primary_text = 2131099751;
    public static final int place_autocomplete_prediction_primary_text_highlight = 2131099752;
    public static final int place_autocomplete_prediction_secondary_text = 2131099753;
    public static final int place_autocomplete_search_hint = 2131099754;
    public static final int place_autocomplete_search_text = 2131099755;
    public static final int place_autocomplete_separator = 2131099756;
    
    public color() {}
  }
  
  public static final class dimen
  {
    public static final int place_autocomplete_button_padding = 2131165347;
    public static final int place_autocomplete_powered_by_google_height = 2131165348;
    public static final int place_autocomplete_powered_by_google_start = 2131165349;
    public static final int place_autocomplete_prediction_height = 2131165350;
    public static final int place_autocomplete_prediction_horizontal_margin = 2131165351;
    public static final int place_autocomplete_prediction_primary_text = 2131165352;
    public static final int place_autocomplete_prediction_secondary_text = 2131165353;
    public static final int place_autocomplete_progress_horizontal_margin = 2131165354;
    public static final int place_autocomplete_progress_size = 2131165355;
    public static final int place_autocomplete_separator_start = 2131165356;
    
    public dimen() {}
  }
  
  public static final class drawable
  {
    public static final int common_full_open_on_phone = 2131230816;
    public static final int common_google_signin_btn_icon_dark = 2131230817;
    public static final int common_google_signin_btn_icon_dark_focused = 2131230818;
    public static final int common_google_signin_btn_icon_dark_normal = 2131230819;
    public static final int common_google_signin_btn_icon_dark_normal_background = 2131230820;
    public static final int common_google_signin_btn_icon_disabled = 2131230821;
    public static final int common_google_signin_btn_icon_light = 2131230822;
    public static final int common_google_signin_btn_icon_light_focused = 2131230823;
    public static final int common_google_signin_btn_icon_light_normal = 2131230824;
    public static final int common_google_signin_btn_icon_light_normal_background = 2131230825;
    public static final int common_google_signin_btn_text_dark = 2131230826;
    public static final int common_google_signin_btn_text_dark_focused = 2131230827;
    public static final int common_google_signin_btn_text_dark_normal = 2131230828;
    public static final int common_google_signin_btn_text_dark_normal_background = 2131230829;
    public static final int common_google_signin_btn_text_disabled = 2131230830;
    public static final int common_google_signin_btn_text_light = 2131230831;
    public static final int common_google_signin_btn_text_light_focused = 2131230832;
    public static final int common_google_signin_btn_text_light_normal = 2131230833;
    public static final int common_google_signin_btn_text_light_normal_background = 2131230834;
    public static final int googleg_disabled_color_18 = 2131230844;
    public static final int googleg_standard_color_18 = 2131230845;
    public static final int places_ic_clear = 2131230989;
    public static final int places_ic_search = 2131230990;
    public static final int powered_by_google_dark = 2131230991;
    public static final int powered_by_google_light = 2131230992;
    
    public drawable() {}
  }
  
  public static final class id
  {
    public static final int adjust_height = 2131296288;
    public static final int adjust_width = 2131296289;
    public static final int auto = 2131296315;
    public static final int center = 2131296338;
    public static final int dark = 2131296366;
    public static final int hybrid = 2131296463;
    public static final int icon_only = 2131296466;
    public static final int light = 2131296503;
    public static final int none = 2131296544;
    public static final int normal = 2131296545;
    public static final int place_autocomplete_clear_button = 2131296573;
    public static final int place_autocomplete_powered_by_google = 2131296574;
    public static final int place_autocomplete_prediction_primary_text = 2131296575;
    public static final int place_autocomplete_prediction_secondary_text = 2131296576;
    public static final int place_autocomplete_progress = 2131296577;
    public static final int place_autocomplete_search_button = 2131296578;
    public static final int place_autocomplete_search_input = 2131296579;
    public static final int place_autocomplete_separator = 2131296580;
    public static final int radio = 2131296593;
    public static final int satellite = 2131296628;
    public static final int standard = 2131296683;
    public static final int terrain = 2131296708;
    public static final int text = 2131296709;
    public static final int text2 = 2131296710;
    public static final int toolbar = 2131296727;
    public static final int wide = 2131296763;
    public static final int wrap_content = 2131296772;
    
    public id() {}
  }
  
  public static final class integer
  {
    public static final int google_play_services_version = 2131361799;
    
    public integer() {}
  }
  
  public static final class layout
  {
    public static final int place_autocomplete_fragment = 2131427443;
    public static final int place_autocomplete_item_powered_by_google = 2131427444;
    public static final int place_autocomplete_item_prediction = 2131427445;
    public static final int place_autocomplete_progress = 2131427446;
    
    public layout() {}
  }
  
  public static final class string
  {
    public static final int common_google_play_services_enable_button = 2131689561;
    public static final int common_google_play_services_enable_text = 2131689562;
    public static final int common_google_play_services_enable_title = 2131689563;
    public static final int common_google_play_services_install_button = 2131689564;
    public static final int common_google_play_services_install_text = 2131689565;
    public static final int common_google_play_services_install_title = 2131689566;
    public static final int common_google_play_services_notification_channel_name = 2131689567;
    public static final int common_google_play_services_notification_ticker = 2131689568;
    public static final int common_google_play_services_unknown_issue = 2131689569;
    public static final int common_google_play_services_unsupported_text = 2131689570;
    public static final int common_google_play_services_update_button = 2131689571;
    public static final int common_google_play_services_update_text = 2131689572;
    public static final int common_google_play_services_update_title = 2131689573;
    public static final int common_google_play_services_updating_text = 2131689574;
    public static final int common_google_play_services_wear_update_text = 2131689575;
    public static final int common_open_on_phone = 2131689576;
    public static final int common_signin_button_text = 2131689577;
    public static final int common_signin_button_text_long = 2131689578;
    public static final int place_autocomplete_clear_button = 2131689731;
    public static final int place_autocomplete_search_hint = 2131689732;
    
    public string() {}
  }
  
  public static final class styleable
  {
    public static final int[] LoadingImageView = { 2130968672, 2130968774, 2130968775 };
    public static final int LoadingImageView_circleCrop = 0;
    public static final int LoadingImageView_imageAspectRatio = 1;
    public static final int LoadingImageView_imageAspectRatioAdjust = 2;
    public static final int[] MapAttrs = { 2130968617, 2130968655, 2130968656, 2130968657, 2130968658, 2130968659, 2130968660, 2130968661, 2130968787, 2130968788, 2130968789, 2130968790, 2130968859, 2130968862, 2130968996, 2130968997, 2130968998, 2130968999, 2130969000, 2130969001, 2130969002, 2130969004, 2130969017 };
    public static final int MapAttrs_ambientEnabled = 0;
    public static final int MapAttrs_cameraBearing = 1;
    public static final int MapAttrs_cameraMaxZoomPreference = 2;
    public static final int MapAttrs_cameraMinZoomPreference = 3;
    public static final int MapAttrs_cameraTargetLat = 4;
    public static final int MapAttrs_cameraTargetLng = 5;
    public static final int MapAttrs_cameraTilt = 6;
    public static final int MapAttrs_cameraZoom = 7;
    public static final int MapAttrs_latLngBoundsNorthEastLatitude = 8;
    public static final int MapAttrs_latLngBoundsNorthEastLongitude = 9;
    public static final int MapAttrs_latLngBoundsSouthWestLatitude = 10;
    public static final int MapAttrs_latLngBoundsSouthWestLongitude = 11;
    public static final int MapAttrs_liteMode = 12;
    public static final int MapAttrs_mapType = 13;
    public static final int MapAttrs_uiCompass = 14;
    public static final int MapAttrs_uiMapToolbar = 15;
    public static final int MapAttrs_uiRotateGestures = 16;
    public static final int MapAttrs_uiScrollGestures = 17;
    public static final int MapAttrs_uiTiltGestures = 18;
    public static final int MapAttrs_uiZoomControls = 19;
    public static final int MapAttrs_uiZoomGestures = 20;
    public static final int MapAttrs_useViewLifecycle = 21;
    public static final int MapAttrs_zOrderOnTop = 22;
    public static final int[] SignInButton = { 2130968650, 2130968689, 2130968900 };
    public static final int SignInButton_buttonSize = 0;
    public static final int SignInButton_colorScheme = 1;
    public static final int SignInButton_scopeUris = 2;
    
    public styleable() {}
  }
}
